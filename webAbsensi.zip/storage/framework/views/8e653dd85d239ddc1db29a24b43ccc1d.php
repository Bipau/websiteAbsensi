<div>
    <!-- Nothing worth having comes easy. - Theodore Roosevelt -->
</div>
<?php /**PATH /home/bipau/dev/laravel-project/WebKelolAbsensi/resources/views/index.blade.php ENDPATH**/ ?>