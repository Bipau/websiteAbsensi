<form wire:submit="update">
    <div class="form-group">
        <label>Kode Mapel</label>
        <input type="text" class="form-control" wire:model="kode_mapel">
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['kode_mapel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
    </div>

    <div class="form-group">
        <label>Nama Mapel</label>
        <input type="text" class="form-control" wire:model="nama_mapel">
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nama_mapel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
    </div>

    <button type="submit" class="btn btn-primary">Save</button>
    <button type="button" class="btn btn-secondary" wire:click="$set('addPage', false)">Close</button>
</form>
<?php /**PATH /home/bipau/dev/laravel-project/WebKelolAbsensi/resources/views/Mapel/edit.blade.php ENDPATH**/ ?>