<?php $__env->startSection('title', 'Kelas'); ?>
<?php $__env->startSection('content'); ?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('kelas-component');

$__html = app('livewire')->mount($__name, $__params, 'lw-3860259908-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/bipau/dev/laravel-project/WebKelolAbsensi/resources/views/Kelas/index.blade.php ENDPATH**/ ?>