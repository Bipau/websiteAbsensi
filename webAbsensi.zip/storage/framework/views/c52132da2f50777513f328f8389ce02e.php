<div>
    <!-- Breathing in, I calm body and mind. Breathing out, I smile. - Thich Nhat Hanh -->
</div>
<?php /**PATH /home/bipau/dev/laravel-project/WebKelolAbsensi/resources/views/Kelas/edit.blade.php ENDPATH**/ ?>