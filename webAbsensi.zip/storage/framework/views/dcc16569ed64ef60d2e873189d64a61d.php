<!-- resources/views/livewire/absen-gerbang-component.blade.php -->
<div>
    <!-- Page Header -->
    <div class="page-header">
        <div class="page-title">
            <h4>Absensi Gerbang</h4>
            <h6>Sistem Absensi Masuk dan Keluar</h6>
        </div>
    </div>

    <!-- Alert Messages -->
    <!--[if BLOCK]><![endif]--><?php if(session()->has('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle me-2"></i><?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <?php if(session()->has('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-circle me-2"></i><?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <div class="row">
        <!-- Left Column - Absen Form -->
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title mb-4">Form Absensi</h5>

                    <form wire:submit.prevent="absenMasuk" class="needs-validation" novalidate>
                        <!-- Camera Section -->
                        <div class="mb-4">
                            <label class="form-label">Foto Absensi</label>
                            <div class="d-flex flex-column align-items-center">
                                <div class="position-relative mb-3">
                                    <!--[if BLOCK]><![endif]--><?php if($foto): ?>
                                        <!--[if BLOCK]><![endif]--><?php if(is_string($foto)): ?>
                                            <img src="<?php echo e(Storage::url($foto)); ?>" class="img-fluid rounded"
                                                style="max-width: 320px; max-height: 240px;">
                                        <?php else: ?>
                                            <img src="<?php echo e($foto->temporaryUrl()); ?>" class="img-fluid rounded"
                                                style="max-width: 320px; max-height: 240px;">
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    <?php else: ?>
                                        <div id="camera-preview" class="bg-light rounded d-flex align-items-center justify-content-center"
                                            style="width: 320px; height: 240px;">
                                            <video id="video" width="320" height="240" autoplay playsinline style="display: none;"></video>
                                            <canvas id="canvas" width="320" height="240" style="display: none;"></canvas>
                                            <i class="fas fa-camera fa-3x text-muted"></i>
                                        </div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>

                                <div class="d-flex gap-2">
                                    <button type="button" class="btn btn-primary" id="startCamera">
                                        <i class="fas fa-video me-2"></i>Buka Kamera
                                    </button>
                                    <button type="button" class="btn btn-success" id="takePhoto" style="display: none;">
                                        <i class="fas fa-camera me-2"></i>Ambil Foto
                                    </button>
                                    <!--[if BLOCK]><![endif]--><?php if($foto): ?>
                                        <button type="button" class="btn btn-danger" wire:click="resetFoto">
                                            <i class="fas fa-times me-2"></i>Hapus
                                        </button>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>

                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger mt-2"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>

                        <!-- Location Section -->
                        <div class="mb-4">
                            <label class="form-label">Lokasi</label>
                            <div class="d-flex flex-column gap-2">
                                <button type="button" class="btn btn-info" wire:click="getLocation">
                                    <i class="fas fa-map-marker-alt me-2"></i>Ambil Lokasi
                                </button>

                                <!--[if BLOCK]><![endif]--><?php if($latitude && $longitude): ?>
                                    <div class="alert alert-success mb-0">
                                        <i class="fas fa-check-circle me-2"></i>Lokasi berhasil diambil
                                        <div class="small text-muted mt-1">
                                            Latitude: <?php echo e($latitude); ?>, Longitude: <?php echo e($longitude); ?>

                                        </div>
                                    </div>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                <input type="hidden" wire:model="latitude">
                                <input type="hidden" wire:model="longitude">
                            </div>
                        </div>

                        <!-- Submit Buttons -->
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-success" wire:loading.attr="disabled">
                                <span wire:loading.remove>
                                    <i class="fas fa-sign-in-alt me-2"></i>Absen Masuk
                                </span>
                                <span wire:loading>
                                    <span class="spinner-border spinner-border-sm me-2"></span>
                                    Memproses...
                                </span>
                            </button>

                            <button type="button" wire:click="absenKeluar" class="btn btn-danger"
                                wire:loading.attr="disabled">
                                <span wire:loading.remove wire:target="absenKeluar">
                                    <i class="fas fa-sign-out-alt me-2"></i>Absen Keluar
                                </span>
                                <span wire:loading wire:target="absenKeluar">
                                    <span class="spinner-border spinner-border-sm me-2"></span>
                                    Memproses...
                                </span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Right Column - Status -->
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title mb-4">Status Absensi</h5>

                    <div class="text-center">
                        <div class="mb-4">
                            <h3 id="current-time" class="display-6 fw-bold text-primary"></h3>
                            <p class="text-muted"><?php echo e(now()->format('l, d F Y')); ?></p>
                        </div>

                        <div class="d-flex flex-column gap-3">
                            <div class="p-3 border rounded bg-light">
                                <h6 class="mb-2">Jam Masuk</h6>
                                <p class="mb-0 fs-5"><?php echo e($jamMasuk ?? '-'); ?></p>
                            </div>

                            <div class="p-3 border rounded bg-light">
                                <h6 class="mb-2">Status</h6>
                                <span class="badge bg-<?php echo e($status === 'Tepat Waktu' ? 'success' : ($status === 'Terlambat' ? 'warning' : 'secondary')); ?> fs-6">
                                    <?php echo e($status ?? 'Belum Absen'); ?>

                                </span>
                            </div>

                            <div class="p-3 border rounded bg-light">
                                <h6 class="mb-2">Jam Keluar</h6>
                                <p class="mb-0 fs-5"><?php echo e($jamKeluar ?? '-'); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    let video = null;
    let canvas = null;
    let stream = null;

    document.getElementById('startCamera').addEventListener('click', async function() {
        try {
            video = document.getElementById('video');
            canvas = document.getElementById('canvas');
            const preview = document.getElementById('camera-preview');
            const startButton = document.getElementById('startCamera');
            const takePhotoButton = document.getElementById('takePhoto');
            const iconPlaceholder = preview.querySelector('i');

            stream = await navigator.mediaDevices.getUserMedia({
                video: {
                    facingMode: 'user',
                    width: { ideal: 320 },
                    height: { ideal: 240 }
                }
            });

            video.srcObject = stream;
            video.style.display = 'block';
            iconPlaceholder.style.display = 'none';
            startButton.style.display = 'none';
            takePhotoButton.style.display = 'block';

        } catch (err) {
            Swal.fire({
                icon: 'error',
                title: 'Gagal mengakses kamera',
                text: 'Mohon izinkan akses kamera untuk melakukan absensi'
            });
            console.error('Error:', err);
        }
    });

    document.getElementById('takePhoto').addEventListener('click', function() {
        if (video && canvas) {
            const context = canvas.getContext('2d');
            context.drawImage(video, 0, 0, canvas.width, canvas.height);

            canvas.toBlob(function(blob) {
                const file = new File([blob], "photo.jpg", { type: "image/jpeg" });

                // Create a DataTransfer object and add the file
                const dataTransfer = new DataTransfer();
                dataTransfer.items.add(file);

                // Dispatch to Livewire
                Livewire.dispatch('foto-captured', { foto: canvas.toDataURL('image/jpeg') });

                // Stop camera
                if (stream) {
                    stream.getTracks().forEach(track => track.stop());
                    video.style.display = 'none';
                    document.getElementById('startCamera').style.display = 'block';
                    document.getElementById('takePhoto').style.display = 'none';
                }
            }, 'image/jpeg');
        }
    });

    // Cleanup on page unload
    window.addEventListener('beforeunload', function() {
        if (stream) {
            stream.getTracks().forEach(track => track.stop());
        }
    });
    document.addEventListener('livewire:initialized', () => {
    window.Livewire.find('<?php echo e($_instance->getId()); ?>').on('getLocation', () => {
        if ("geolocation" in navigator) {
            navigator.geolocation.getCurrentPosition(
                function(position) {
                    // Update the dispatch to send individual parameters
                    Livewire.dispatch('setLocation', {
                        lat: position.coords.latitude,
                        lng: position.coords.longitude
                    });
                },
                function(error) {
                    let errorMessage = 'Gagal mendapatkan lokasi: ';
                    switch(error.code) {
                        case error.PERMISSION_DENIED:
                            errorMessage += "Izin akses lokasi ditolak.";
                            break;
                        case error.POSITION_UNAVAILABLE:
                            errorMessage += "Informasi lokasi tidak tersedia.";
                            break;
                        case error.TIMEOUT:
                            errorMessage += "Waktu permintaan lokasi habis.";
                            break;
                        default:
                            errorMessage += "Terjadi kesalahan.";
                    }
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: errorMessage
                    });
                },
                {
                    enableHighAccuracy: true,
                    timeout: 5000,
                    maximumAge: 0
                }
            );
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Browser Anda tidak mendukung geolokasi.'
            });
        }
    });
});
    </script>
<?php /**PATH /home/bipau/dev/laravel-project/WebKelolAbsensi/resources/views/livewire/absen-gerbang-component.blade.php ENDPATH**/ ?>