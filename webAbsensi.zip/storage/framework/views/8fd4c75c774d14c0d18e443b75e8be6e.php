<div class="sidebar" id="sidebar">
    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu" class="sidebar-menu">
            <ul>
                
                <li>
                    <a href="<?php echo e(route('dashboard')); ?>">
                        <img src="assets/img/icons/dashboard.svg" alt="img">
                        <span>Dashboard</span>
                    </a>
                </li>

                
                <?php if(auth()->user()->role === 'admin'): ?>
                <li class="submenu">
                    <a href="javascript:void(0);">
                        <img src="assets/img/icons/users1.svg" alt="img">
                        <span>Users</span>
                        <span class="menu-arrow"></span>
                    </a>
                    <ul>
                        <li><a href="<?php echo e(route('users')); ?>">Users List</a></li>
                        <li><a href="<?php echo e(route('siswa')); ?>">Users Siswa</a></li>
                        <li><a href="<?php echo e(route('karyawan')); ?>">Users Karyawan</a></li>
                    </ul>
                </li>
                <?php endif; ?>

                
                <?php if(auth()->user()->role === 'admin'): ?>
                <li>
                    <a href="<?php echo e(route('kelas')); ?>">
                        <img src="assets/img/icons/dashboard.svg" alt="img">
                        <span>Kelas</span>
                    </a>
                </li>
                <?php endif; ?>

                
                <?php if(auth()->user()->role === ['admin','kesiswaan']): ?>
                <li class="submenu">
                    <a href="javascript:void(0);">
                        <img src="assets/img/icons/users1.svg" alt="img">
                        <span>Mapel</span>
                        <span class="menu-arrow"></span>
                    </a>
                    <ul>
                        <li><a href="<?php echo e(route('mapel')); ?>">Mapel</a></li>
                        <li><a href="<?php echo e(route('guruMapel')); ?>">Mapel & Pengampu</a></li>
                        <li><a href="<?php echo e(route('jadwal')); ?>">Jadwal Mapel</a></li>
                    </ul>
                </li>
                <?php endif; ?>

                
                <?php if(in_array(auth()->user()->role, ['admin', 'guru', 'karyawan','kurikulum','walikelas'])): ?>
                <li class="submenu">
                    <a href="javascript:void(0);">
                        <img src="assets/img/icons/users1.svg" alt="img">
                        <span>Absensi</span>
                        <span class="menu-arrow"></span>
                    </a>
                    <ul>
                        <li><a href="<?php echo e(route('AbsenGerbang')); ?>">Absen Gerbang</a></li>
                        <?php if(auth()->user()->role === 'admin'): ?>
                        <li><a href="<?php echo e(route('kelolaAbsenGerbang')); ?>">Kelola Absen Gerbang</a></li>
                        <?php endif; ?>
                        <li><a href="<?php echo e(route('AbsenKelas')); ?>">Absen Kelas</a></li>
                        <li><a href="<?php echo e(route('generateQr')); ?>">QR Absen</a></li>
                    </ul>
                </li>
                <?php endif; ?>

                
                <?php if(auth()->user()->role === 'siswa'): ?>
                <li>
                    <a href="<?php echo e(route('AbsenGerbang')); ?>">
                        <img src="assets/img/icons/dashboard.svg" alt="img">
                        <span>Absen Gerbang</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('siswa-absen-kelas')); ?>">
                        <img src="assets/img/icons/dashboard.svg" alt="img">
                        <span>Absen Kelas</span>
                    </a>
                </li>
                <?php endif; ?>

            </ul>
        </div>
    </div>
</div>
<?php /**PATH /home/bipau/dev/laravel-project/WebKelolAbsensi/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>