<div>
        <div class="page-header">
            <div class="page-title">
                <h4>Form Absensi Siswa</h4>
                <h6>Kelola Absensi Siswa</h6>
            </div>
        </div>

        <!-- Alert Messages -->
        <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        <?php if(session()->has('error')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        <div class="card">
            <div class="card-body">
                <!-- Filter Section -->
                <div class="row mb-3">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Kelas <span class="text-danger">*</span></label>
                            <select wire:model.live="kelas_id" class="form-select">
                                <option value="">Pilih Kelas</option>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $kelasList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($kelas->id); ?>"><?php echo e($kelas->nama_kelas); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </select>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['kelas_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Jadwal Pelajaran <span class="text-danger">*</span></label>
                            <select wire:model.live="jadwal_id" class="form-select" <?php echo e(empty($kelas_id) ? 'disabled' : ''); ?>>
                                <option value="">Pilih Jadwal</option>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $jadwalList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jadwal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($jadwal->id); ?>">
                                        <?php echo e($jadwal->nama_mapel); ?> - <?php echo e($jadwal->hari); ?> 
                                        (<?php echo e($jadwal->jam_mulai); ?> - <?php echo e($jadwal->jam_selesai); ?>)
                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </select>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['jadwal_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Tanggal <span class="text-danger">*</span></label>
                            <input type="date" wire:model.live="tanggal" class="form-control">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                </div>

                <!-- Loading State -->
                <div wire:loading wire:target="kelas_id" class="text-center my-3">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="text-muted">Memuat data siswa...</p>
                </div>

                <!-- Students List Table -->
                <!--[if BLOCK]><![endif]--><?php if(count($siswaList) > 0): ?>
                    <div class="table-top mb-3">
                        <div class="text-end">
                            <div class="form-check">
                                <input type="checkbox" class="form-check-input" id="selectAll"
                                    wire:click="$set('hadir', <?php echo \Illuminate\Support\Js::from(array_fill_keys($siswaList->pluck('id')->toArray(), true))->toHtml() ?>)">
                                <label class="form-check-label" for="selectAll">Pilih Semua</label>
                            </div>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>NIS</th>
                                    <th>Nama Siswa</th>
                                    <th class="text-center">Status Kehadiran</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $siswaList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td><?php echo e($siswa->nis); ?></td>
                                        <td><?php echo e($siswa->user->nama); ?></td>
                                        <td class="text-center">
                                            <div class="btn-group" role="group">
                                                <input type="radio" 
                                                    class="btn-check" 
                                                    name="status_<?php echo e($siswa->id); ?>" 
                                                    id="hadir_<?php echo e($siswa->id); ?>" 
                                                    wire:model.live="status.<?php echo e($siswa->id); ?>" 
                                                    value="Hadir">
                                                <label class="btn btn-outline-success btn-sm" for="hadir_<?php echo e($siswa->id); ?>">
                                                    <i class="fas fa-check me-1"></i>Hadir
                                                </label>

                                                <input type="radio" 
                                                    class="btn-check" 
                                                    name="status_<?php echo e($siswa->id); ?>" 
                                                    id="izin_<?php echo e($siswa->id); ?>" 
                                                    wire:model.live="status.<?php echo e($siswa->id); ?>" 
                                                    value="Izin">
                                                <label class="btn btn-outline-warning btn-sm" for="izin_<?php echo e($siswa->id); ?>">
                                                    <i class="fas fa-envelope me-1"></i>Izin
                                                </label>

                                                <input type="radio" 
                                                    class="btn-check" 
                                                    name="status_<?php echo e($siswa->id); ?>" 
                                                    id="alpha_<?php echo e($siswa->id); ?>" 
                                                    wire:model.live="status.<?php echo e($siswa->id); ?>" 
                                                    value="Alpha">
                                                <label class="btn btn-outline-danger btn-sm" for="alpha_<?php echo e($siswa->id); ?>">
                                                    <i class="fas fa-times me-1"></i>Alpha
                                                </label>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </tbody>
                        </table>
                    </div>

                    <!-- Submit Button -->
                    <div class="text-end mt-3">
                        <button wire:click="simpan" class="btn btn-primary" 
                            <?php echo e(empty($kelas_id) || empty($jadwal_id) || empty($tanggal) ? 'disabled' : ''); ?>>
                            <span wire:loading.remove wire:target="simpan">
                                <i class="fas fa-save me-1"></i> Simpan Absen
                            </span>
                            <span wire:loading wire:target="simpan">
                                <span class="spinner-border spinner-border-sm me-1" role="status" aria-hidden="true"></span>
                                Menyimpan...
                            </span>
                        </button>
                    </div>
                <?php elseif($kelas_id): ?>
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        Tidak ada siswa yang terdaftar dalam kelas ini.
                    </div>
                <?php else: ?>
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        Silahkan pilih kelas terlebih dahulu untuk menampilkan daftar siswa.
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>
    </div>
<?php /**PATH /home/bipau/dev/laravel-project/WebKelolAbsensi/resources/views/livewire/guru-absen-kelas-component.blade.php ENDPATH**/ ?>