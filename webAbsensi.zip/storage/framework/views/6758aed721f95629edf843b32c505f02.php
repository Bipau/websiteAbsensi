<!-- filepath: /home/bipau/dev/laravel-project/WebKelolAbsensi/resources/views/livewire/generate-qr-code-component.blade.php -->
<div>
    <div class="page-header">
        <div class="page-title">
            <h4>Generate QR Code Absensi</h4>
            <h6>Generate QR Code untuk Absensi Kelas</h6>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title mb-4">Form Generate QR</h5>

                    <div class="mb-4">
                        <label class="form-label">Pilih Kelas</label>
                        <select wire:model="kelas_id" class="form-select">
                            <option value="">-- Pilih Kelas --</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $kelasList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($kelas->id); ?>"><?php echo e($kelas->nama_kelas); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </select>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['kelas_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                            <div class="text-danger mt-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Pilih Jadwal Pelajaran</label>
                        <select wire:model="jadwal_id" class="form-select">
                            <option value="">-- Pilih Jadwal --</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $jadwalList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jadwal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($jadwal->id); ?>">
                                    <?php echo e($jadwal->mapel->nama_mapel ?? 'Mapel'); ?> - 
                                    <?php echo e($jadwal->hari); ?> 
                                    (<?php echo e(\Carbon\Carbon::parse($jadwal->jam_mulai)->format('H:i')); ?> - 
                                    <?php echo e(\Carbon\Carbon::parse($jadwal->jam_selesai)->format('H:i')); ?>)
                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </select>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['jadwal_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                            <div class="text-danger mt-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <button wire:click="generate" class="btn btn-primary" wire:loading.attr="disabled">
                        <i class="fas fa-qrcode me-2"></i>
                        <span wire:loading.remove>Generate QR Code</span>
                        <span wire:loading>Generating...</span>
                    </button>
                </div>
            </div>
        </div>

        <!--[if BLOCK]><![endif]--><?php if($token): ?>
        <div class="col-md-6">
            <div class="card">
                <div class="card-body text-center">
                    <h5 class="card-title mb-4">QR Code</h5>

                    <div class="qr-container p-4 bg-light rounded mb-4">
                        <img src="https://api.qrserver.com/v1/create-qr-code/?data=<?php echo e($token); ?>&size=200x200" 
                            alt="QR Code" 
                            class="img-fluid mb-3"
                            style="max-width: 200px;">
                        
                        <div class="mt-3">
                            <p class="mb-2"><strong>Token:</strong> 
                                <span class="badge bg-primary"><?php echo e($token); ?></span>
                            </p>
                            <p class="mb-0"><strong>Kadaluarsa:</strong> 
                                <span class="badge bg-warning text-dark">
                                    <?php echo e(\Carbon\Carbon::parse($expiredAt)->format('d M Y H:i')); ?>

                                </span>
                            </p>
                        </div>
                    </div>

                    <div class="d-flex justify-content-center gap-2">
                        <button onclick="window.print()" class="btn btn-info">
                            <i class="fas fa-print me-2"></i>Print QR
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>

// Add print styles
const style = document.createElement('style');
style.textContent = `
    @media print {
        body * {
            visibility: hidden;
        }
        .qr-container, .qr-container * {
            visibility: visible;
        }
        .qr-container {
            position: absolute;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
        }
    }
`;
document.head.appendChild(style);
</script>
<?php $__env->stopPush(); ?><?php /**PATH /home/bipau/dev/laravel-project/WebKelolAbsensi/resources/views/livewire/generate-qr-code-component.blade.php ENDPATH**/ ?>