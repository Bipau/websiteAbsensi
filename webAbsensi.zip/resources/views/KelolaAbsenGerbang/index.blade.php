@extends('layouts.app')
@section('title', 'Kelola Absen Gerbang')
@section('content')
    @livewire('KelolaAbsenGerbang')
@endsection
