@extends('layouts.app')
@section('title', 'Mapel')
@section('content')
    @livewire('mapel-component')
@endsection