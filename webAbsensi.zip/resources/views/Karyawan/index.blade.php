@extends('layouts.app')
@section('title', 'Karyawan')
@section('content')

    @livewire('KaryawanComponent')
@endsection