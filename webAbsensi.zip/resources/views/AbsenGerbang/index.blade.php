@extends('layouts.app')
@section('title', 'Absen Gerbang')
@section('content')

<livewire:absen-gerbang-component>

@endsection
    