@extends('layouts.app')
@section('title', 'Generate QR Code')
@section('content')

<livewire:generate-qr-code-component/>
@endsection
