@extends('layouts.app')
@section('title', 'Guru Mapel')
@section('content')
    @livewire('guru-mapel-component')
@endsection
