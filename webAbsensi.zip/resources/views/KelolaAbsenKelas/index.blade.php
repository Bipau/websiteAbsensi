@extends('layouts.app')
@section('title', 'Generate QR Code')
@section('content')

<livewire:guru-absen-kelas-component />
@endsection
