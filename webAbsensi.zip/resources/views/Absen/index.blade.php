@extends('layouts.app')

@section('title', 'Absen')

@section('content')
    @livewire('absen-kelas-component ')
    {{-- <livewire:guru-absen-kelas-component> --}}

@endsection
