@extends('layouts.app')
@section('title', 'Dashboard')
@section('content')
    @livewire('DashboardComponent')
@endsection
