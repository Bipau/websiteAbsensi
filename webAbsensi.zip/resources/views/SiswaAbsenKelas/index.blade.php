@extends('layouts.app')
@section('title', 'Siswa Absen Kelas')
@section('content')

<livewire:siswa-absen-kelas-component>

@endsection
