@extends('layouts.app')
@section('title', 'Jadwal')

@section('content')
    @livewire('JadwalComponent')
@endsection
