@extends('layouts.app')
@section('title', 'Siswa')
@section('content')
    @livewire('SiswaComponent')
@endsection
