@extends('layouts.app')
@section('title', 'Kelas')
@section('content')
    @livewire('kelas-component')
@endsection